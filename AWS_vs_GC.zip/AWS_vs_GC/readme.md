beginning of a project for school

started with google cloud.

porting to aws in the future